
#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

int main()
{

    while(1)
    {
        unsigned char continu = 0;

        main_menu();

        printf("\ndo you want to continue?\npress 1 for yes or 0 for no\t");
        fflush(stdin);
        scanf("%d", &continu);
        if (continu == 0)
        {
            printf("\ngoodbye!\n");
            break;
        }
    }

}
